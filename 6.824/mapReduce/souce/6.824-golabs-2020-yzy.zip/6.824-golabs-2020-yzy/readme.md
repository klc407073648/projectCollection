#### mit 6.824 2020

- [x] lab1 mr
- [x] lab2 raft
- [x] lab3 kvraft
- [x] lab4 shardkv
    - [x] challenge1
    - [x] challenge2

##### TODO
- [ ] 优化 if else 减少代码
- [ ] 降低 cpu 使用
- [ ] raft figure8 test 出现过一次 FAIL，需重现
-----

* 2020/03/06 
    整理上传代码
